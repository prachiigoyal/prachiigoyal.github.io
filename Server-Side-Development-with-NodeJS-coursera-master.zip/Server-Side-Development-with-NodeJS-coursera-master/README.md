# Solutions for assignment for the Server side development course with NodeJS - Coursera.


## Contains solutions for all the four weeks: 


  Week 1 - Introduction to Server-side Development

  Week 2 - "Data, Data, Where art Thou Data?" (MongoDB integration)

 Week 3 - "Halt! Who goes there?" (Security)

 Week 4 - "Backend as a Service" (BaaS)
